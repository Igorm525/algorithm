# 3. В массиве случайных целых чисел поменять местами минимальный и максимальный элементы.
from random import randint

array = [randint(0, 100) for _ in range(randint(5, 20))]
_min = _max = array[0]
for i in array:
    if i < _min:
        _min = i
    if i > _max:
        _max = i

min_key = array.index(_min)
max_key = array.index(_max)

print(f'Исходный массив {array}')
array[min_key], array[max_key] = array[max_key], array[min_key]
print(f'Выходной массив {array}')

